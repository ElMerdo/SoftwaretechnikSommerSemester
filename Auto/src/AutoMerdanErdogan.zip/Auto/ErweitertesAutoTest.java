package Auto;

public class ErweitertesAutoTest {
	public static void main(String[] args) {
		ErweitertesAuto pkw1 = new ErweitertesAuto("Hans2", "SUV", "Gr�n", 2010, 160, 80000, "Berlin", "S12U34V56");
		ErweitertesAuto pkw2 = new ErweitertesAuto("Peter2", "Pickup", "Gelb", 2015, 100, 40000, "K�ln", "P12I34C56K78");
		ErweitertesAuto pkw3 = new ErweitertesAuto("Micha2", "Kleinwagen", "Grau", 2017, 70, 20000, "Hamburg", "K12L34E56I78N90");
		
		System.out.println("Pkw1 hat die Fahrgestellnummer " + pkw1.getFahrgestellnummer());
		System.out.println();
		pkw2.SetzeNeuesZiel("Berlin", 300);
		System.out.println();
		System.out.println(pkw3.toString());
		System.out.println();
		System.out.println("Projekt von Merdan Erdogan");
	}
}
