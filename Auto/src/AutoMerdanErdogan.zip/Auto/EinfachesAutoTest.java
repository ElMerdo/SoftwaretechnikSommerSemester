package Auto;

public class EinfachesAutoTest {
	public static void main(String[] args) {
		EinfachesAuto auto1 = new EinfachesAuto("Hans", "Coupe", "Schwarz Matt", 2019, 150, 5000);
		EinfachesAuto auto2 = new EinfachesAuto("Peter", "Limousine", "Chrom", 2016, 300, 60000);
		EinfachesAuto auto3 = new EinfachesAuto("Micha", "Cabriolet", "Rot", 2010, 200, 100000);
		System.out.println("Auto 1 ist " + auto1.getAlter());
		auto2.meldung();
		System.out.println();
		System.out.println("Auto 3 ist " + auto3.getAlter());
		System.out.println("Projekt von Merdan Erdogan");
	}
}
